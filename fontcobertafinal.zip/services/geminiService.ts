
import { GoogleGenAI, Chat } from "@google/genai";

let chat: Chat | null = null;

// Fix: Per Gemini API guidelines, API key must be read from process.env.API_KEY.
// The use of import.meta.env is incorrect and was causing a TypeScript error.
const getApiKey = () => {
    return process.env.API_KEY;
}

const initializeChat = (): Chat => {
  const apiKey = getApiKey();
  if (!apiKey) {
    throw new Error("API_KEY is not configured.");
  }
  const ai = new GoogleGenAI({ apiKey });
  return ai.chats.create({
    model: 'gemini-2.5-flash',
    config: {
        systemInstruction: `You are a helpful assistant for the Fontcoberta basketball club. 
        Your audience is coaches, players, and their families. 
        Provide concise and encouraging answers related to basketball training, drills, rules, and motivation. 
        Keep the tone friendly and supportive. Your name is 'Basky'.`,
    },
  });
};

export const getChatbotResponse = async (message: string): Promise<string> => {
  try {
    if (!chat) {
      chat = initializeChat();
    }
    const response = await chat.sendMessage({ message });
    return response.text;
  } catch (error) {
    console.error("Error fetching response from Gemini:", error);
    chat = null; // Reset chat session on error
    if (error instanceof Error && error.message.includes('API_KEY')) {
        return "La meva clau d'API no està configurada. Si us plau, demana a l'administrador que configuri la clau de Gemini al projecte.";
    }
    return "Lo siento, algo salió mal. Por favor, inténtalo de nuevo.";
  }
};
