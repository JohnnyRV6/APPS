
import { Season, AttendanceRecord, User } from '../types';
import { INITIAL_SEASONS, INITIAL_USERS } from '../constants';

const SEASONS_KEY = 'fontcoberta_seasons';
const ATTENDANCE_KEY = 'fontcoberta_attendance';
const USERS_KEY = 'fontcoberta_users';
const ACTIVE_SEASON_ID_KEY = 'fontcoberta_active_season_id';

// Seasons
export const loadSeasons = (): Season[] => {
  try {
    const stored = localStorage.getItem(SEASONS_KEY);
    return stored ? JSON.parse(stored) : INITIAL_SEASONS;
  } catch (error) {
    console.error("Failed to load seasons:", error);
    return INITIAL_SEASONS;
  }
};

export const saveSeasons = (seasons: Season[]): void => {
  try {
    localStorage.setItem(SEASONS_KEY, JSON.stringify(seasons));
  } catch (error) {
    console.error("Failed to save seasons:", error);
  }
};

// Attendance
export const loadAttendance = (): AttendanceRecord => {
  try {
    const stored = localStorage.getItem(ATTENDANCE_KEY);
    return stored ? JSON.parse(stored) : {};
  } catch (error) {
    console.error("Failed to load attendance records:", error);
    return {};
  }
};

export const saveAttendance = (records: AttendanceRecord): void => {
  try {
    localStorage.setItem(ATTENDANCE_KEY, JSON.stringify(records));
  } catch (error) {
    console.error("Failed to save attendance records:", error);
  }
};

// Users
export const loadUsers = (): User[] => {
    try {
      const stored = localStorage.getItem(USERS_KEY);
      return stored ? JSON.parse(stored) : INITIAL_USERS;
    } catch (error) {
      console.error("Failed to load users:", error);
      return INITIAL_USERS;
    }
  };
  
  export const saveUsers = (users: User[]): void => {
    try {
      localStorage.setItem(USERS_KEY, JSON.stringify(users));
    } catch (error) {
      console.error("Failed to save users:", error);
    }
  };

// Active Season ID
export const loadActiveSeasonId = (): string | null => {
  try {
    return localStorage.getItem(ACTIVE_SEASON_ID_KEY);
  } catch (error) {
    console.error("Failed to load active season ID:", error);
    return null;
  }
};

export const saveActiveSeasonId = (id: string | null): void => {
  try {
    if (id) {
      localStorage.setItem(ACTIVE_SEASON_ID_KEY, id);
    } else {
      localStorage.removeItem(ACTIVE_SEASON_ID_KEY);
    }
  } catch (error) {
    console.error("Failed to save active season ID:", error);
  }
};
