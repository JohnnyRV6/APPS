import React, { useState } from 'react';
import { User } from '../types';

interface LoginPageProps {
  onLogin: (username: string, password: string) => boolean;
}

const BasketballIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/>
    <path d="M12 4.44c-4.9 0-8.88 4.66-7.56 9.56s7.56 8.56 12.44 3.68c4.88-4.88 1.2-13.24-4.88-13.24zM12 20c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z" opacity=".1"/>
    <path d="M4.44 14.88L14.88 4.44c-2.34-1.3-5.18-1.04-7.22.99-2.04 2.04-2.29 4.88-.99 7.22zM9.12 19.56L19.56 9.12c2.34 1.3 5.18 1.04 7.22-.99 2.04-2.04 2.29-4.88.99-7.22L9.12 19.56z" opacity=".2"/>
  </svg>
);

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const success = onLogin(username, password);
    if (!success) {
      setError('Usuari o contrasenya incorrectes.');
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col justify-center items-center p-4">
      <div className="max-w-md w-full bg-white rounded-xl shadow-lg p-8 space-y-6">
        <div className="flex flex-col items-center space-y-2">
            <BasketballIcon className="h-12 w-12 text-orange-500" />
            <h1 className="text-2xl font-bold text-gray-800">Club Bàsquet Fontcoberta</h1>
            <p className="text-gray-600">Control d'Assistència</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="username" className="text-sm font-medium text-gray-700">
              Usuari
            </label>
            <input
              id="username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
              className="mt-1 w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <div>
            <label htmlFor="password"className="text-sm font-medium text-gray-700">
              Contrasenya
            </label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="mt-1 w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          {error && <p className="text-sm text-red-600 text-center">{error}</p>}
          <div>
            <button
              type="submit"
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Iniciar sessió
            </button>
          </div>
        </form>
      </div>
       <footer className="text-center p-4 text-gray-500 text-sm mt-8">
        <p>&copy; {new Date().getFullYear()} Club Bàsquet Fontcoberta. Tots els drets reservats.</p>
      </footer>
    </div>
  );
};

export default LoginPage;
