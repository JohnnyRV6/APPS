import React from 'react';

const CogIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    {...props}
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M19.14 12.94c.04-.3.06-.61.06-.94s-.02-.64-.07-.94l2.03-1.58a.5.5 0 0 0 .12-.61l-1.92-3.32a.5.5 0 0 0-.61-.12l-2.39 1.04a7.5 7.5 0 0 0-1.61-.82l-.38-2.65A.5.5 0 0 0 14 2H10a.5.5 0 0 0-.5.42l-.38 2.65a7.5 7.5 0 0 0-1.61.82L4.72 4.84a.5.5 0 0 0-.61.12l-1.92 3.32a.5.5 0 0 0 .12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58a.5.5 0 0 0-.12.61l1.92 3.32a.5.5 0 0 0 .61.12l2.39-1.04a7.5 7.5 0 0 0 1.61.82l.38 2.65a.5.5 0 0 0 .5.42h4a.5.5 0 0 0 .5-.42l.38-2.65a7.5 7.5 0 0 0 1.61-.82l2.39 1.04a.5.5 0 0 0 .61-.12l1.92-3.32a.5.5 0 0 0-.12-.61l-2.01-1.58z" />
    <circle cx="12" cy="12" r="3" />
  </svg>
);

export default CogIcon;
