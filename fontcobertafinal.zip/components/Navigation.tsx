import React from 'react';
import type { Page } from '../types';
import CalendarIcon from './icons/CalendarIcon';
import ChartBarIcon from './icons/ChartBarIcon';
import CogIcon from './icons/CogIcon';

interface NavItem {
  page: Page;
  label: string;
  icon: React.ElementType;
}

const navItems: NavItem[] = [
  { page: 'attendance', label: "Assistència", icon: CalendarIcon },
  { page: 'statistics', label: "Estadístiques", icon: ChartBarIcon },
  { page: 'settings', label: "Configuració", icon: CogIcon },
];

interface NavigationProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
}

const Navigation: React.FC<NavigationProps> = ({ currentPage, onNavigate }) => {
  return (
    <nav className="bg-white shadow-md rounded-lg p-2">
      <ul className="flex justify-center space-x-2 md:space-x-4">
        {navItems.map(({ page, label, icon: Icon }) => (
          <li key={page}>
            <button
              onClick={() => onNavigate(page)}
              className={`flex items-center justify-center px-3 py-2 md:px-4 md:py-2 rounded-md text-sm md:text-base font-medium transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${
                currentPage === page
                  ? 'bg-blue-600 text-white shadow'
                  : 'text-gray-600 hover:bg-gray-200 hover:text-gray-800'
              }`}
            >
              <Icon className="h-5 w-5 mr-2" />
              <span className="hidden md:inline">{label}</span>
            </button>
          </li>
        ))}
      </ul>
    </nav>
  );
};

export default Navigation;
