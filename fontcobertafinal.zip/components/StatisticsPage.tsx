import React, { useState, useEffect, useMemo } from 'react';
import { Season, AttendanceRecord, AttendanceStatus, Team, Person } from '../types';
import SeasonSelector from './SeasonSelector';
import TeamSelector from './TeamSelector';

interface StatisticsPageProps {
  seasons: Season[];
  activeSeasonId: string | null;
  onSetActiveSeason: (seasonId: string) => void;
  attendance: AttendanceRecord;
}

interface PersonStats {
  present: number;
  absent: number;
  justified: number;
  total: number;
}

const calculateStats = (team: Team | null, attendance: AttendanceRecord): Map<string, PersonStats> => {
    const stats = new Map<string, PersonStats>();
    if (!team) return stats;

    team.people.forEach(person => {
        stats.set(person.id, { present: 0, absent: 0, justified: 0, total: 0 });
    });

    for (const date in attendance) {
        const dailyRecords = attendance[date];
        for (const personId in dailyRecords) {
            const personStat = stats.get(personId);
            if (personStat) {
                personStat.total += 1;
                switch (dailyRecords[personId]) {
                    case AttendanceStatus.Present:
                        personStat.present += 1;
                        break;
                    case AttendanceStatus.Absent:
                        personStat.absent += 1;
                        break;
                    case AttendanceStatus.Justified:
                        personStat.justified += 1;
                        break;
                }
            }
        }
    }
    return stats;
};

const StatBar: React.FC<{ value: number; total: number; color: string; }> = ({ value, total, color }) => {
    const percentage = total > 0 ? (value / total) * 100 : 0;
    return (
        <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div className={`${color} h-2.5 rounded-full`} style={{ width: `${percentage}%` }}></div>
        </div>
    );
};

const StatisticsPage: React.FC<StatisticsPageProps> = ({ seasons, activeSeasonId, onSetActiveSeason, attendance }) => {
  const [selectedTeamId, setSelectedTeamId] = useState<string | null>(null);
  
  const activeSeason = seasons.find(s => s.id === activeSeasonId);
  const teams = activeSeason?.teams || [];
  const selectedTeam = teams.find(t => t.id === selectedTeamId) || null;

  // Reset selected team if active season changes or teams load
  useEffect(() => {
    if (activeSeason && activeSeason.teams.length > 0) {
        if (!activeSeason.teams.some(t => t.id === selectedTeamId)) {
            setSelectedTeamId(activeSeason.teams[0].id);
        }
    } else {
        setSelectedTeamId(null);
    }
  }, [activeSeasonId, seasons, selectedTeamId, activeSeason]);
  
  const teamStats = useMemo(() => calculateStats(selectedTeam, attendance), [selectedTeam, attendance]);

  const renderPersonStats = (person: Person) => {
    const stats = teamStats.get(person.id);
    if (!stats || stats.total === 0) {
      return (
        <tr key={person.id} className="border-b border-gray-200">
            <td className="px-4 py-3 font-medium text-gray-800">{person.name}</td>
            <td colSpan={4} className="px-4 py-3 text-gray-500 italic">Sense dades d'assistència</td>
        </tr>
      );
    }
    const presentPerc = ((stats.present / stats.total) * 100).toFixed(0);
    const absentPerc = ((stats.absent / stats.total) * 100).toFixed(0);
    const justifiedPerc = ((stats.justified / stats.total) * 100).toFixed(0);
    
    return (
        <tr key={person.id} className="border-b border-gray-200 hover:bg-gray-50">
            <td className="px-4 py-3 font-medium text-gray-800">{person.name}</td>
            <td className="px-4 py-3 text-center">{stats.total}</td>
            <td className="px-4 py-3">
                <div className="flex items-center gap-2">
                    <span className="w-12 text-right">{presentPerc}%</span>
                    <StatBar value={stats.present} total={stats.total} color="bg-green-500" />
                </div>
            </td>
             <td className="px-4 py-3">
                <div className="flex items-center gap-2">
                    <span className="w-12 text-right">{absentPerc}%</span>
                    <StatBar value={stats.absent} total={stats.total} color="bg-red-500" />
                </div>
            </td>
             <td className="px-4 py-3">
                <div className="flex items-center gap-2">
                    <span className="w-12 text-right">{justifiedPerc}%</span>
                    <StatBar value={stats.justified} total={stats.total} color="bg-yellow-500" />
                </div>
            </td>
        </tr>
    );
  };
  
  return (
    <div className="space-y-6">
      {seasons.length > 1 && (
        <SeasonSelector
          seasons={seasons}
          currentSeasonId={activeSeasonId}
          onSelectSeason={onSetActiveSeason}
        />
      )}
      <TeamSelector
        teams={teams}
        selectedTeamId={selectedTeamId}
        onSelectTeam={setSelectedTeamId}
      />
      <div className="bg-white p-4 sm:p-6 rounded-lg shadow-md">
        <h2 className="text-xl font-bold text-gray-800 mb-4">Estadístiques d'assistència per a {selectedTeam?.name || '...'}</h2>
        {selectedTeam ? (
            <div className="overflow-x-auto">
                <table className="w-full text-sm text-left text-gray-600">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-100">
                        <tr>
                            <th className="px-4 py-3">Nom</th>
                            <th className="px-4 py-3 text-center">Total Dies</th>
                            <th className="px-4 py-3">Present</th>
                            <th className="px-4 py-3">Absent</th>
                            <th className="px-4 py-3">Justificat</th>
                        </tr>
                    </thead>
                    <tbody>
                        {selectedTeam.people.map(renderPersonStats)}
                    </tbody>
                </table>
            </div>
        ) : (
            <p className="text-center text-gray-500 py-8">Si us plau, selecciona un equip per veure les estadístiques.</p>
        )}
      </div>
    </div>
  );
};

export default StatisticsPage;
