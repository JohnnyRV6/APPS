import React from 'react';
import { User } from '../types';
import LogoutIcon from './icons/LogoutIcon';

const BasketballIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/>
    <path d="M12 4.44c-4.9 0-8.88 4.66-7.56 9.56s7.56 8.56 12.44 3.68c4.88-4.88 1.2-13.24-4.88-13.24zM12 20c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z" opacity=".1"/>
    <path d="M4.44 14.88L14.88 4.44c-2.34-1.3-5.18-1.04-7.22.99-2.04 2.04-2.29 4.88-.99 7.22zM9.12 19.56L19.56 9.12c2.34 1.3 5.18 1.04 7.22-.99 2.04-2.04 2.29-4.88.99-7.22L9.12 19.56z" opacity=".2"/>
  </svg>
);


interface HeaderProps {
    currentUser: User | null;
    onLogout: () => void;
    activeSeasonName?: string;
}

const Header: React.FC<HeaderProps> = ({ currentUser, onLogout, activeSeasonName }) => {
  return (
    <header className="bg-slate-800 text-white shadow-md w-full">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
            <BasketballIcon className="h-8 w-8 text-orange-500" />
            <div>
                <h1 className="text-lg md:text-xl font-bold tracking-tight">
                Club Bàsquet Fontcoberta
                </h1>
                {activeSeasonName && <p className="text-xs text-slate-300">Temporada Activa: {activeSeasonName}</p>}
            </div>
        </div>
        {currentUser && (
            <div className="flex items-center gap-4">
                <div className="text-right">
                    <span className="text-sm hidden sm:inline">Benvingut, </span>
                    <span className="font-bold text-sm">{currentUser.username}</span>
                </div>
                <button onClick={onLogout} title="Tancar sessió" className="p-2 rounded-full hover:bg-slate-700 transition-colors">
                    <LogoutIcon className="h-5 w-5"/>
                </button>
            </div>
        )}
      </div>
    </header>
  );
};

export default Header;