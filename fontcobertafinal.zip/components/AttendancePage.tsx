import React, { useState, useEffect } from 'react';
import { Season, AttendanceRecord, AttendanceStatus } from '../types';
import SeasonSelector from './SeasonSelector';
import TeamSelector from './TeamSelector';
import AttendanceTracker from './AttendanceTracker';

interface AttendancePageProps {
  seasons: Season[];
  activeSeasonId: string | null;
  onSetActiveSeason: (seasonId: string) => void;
  attendance: AttendanceRecord;
  onSetAttendanceForDate: (date: string, personId: string, status: AttendanceStatus) => void;
}

const getTodayDateString = (): string => {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, '0');
  const day = String(today.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const AttendancePage: React.FC<AttendancePageProps> = ({ 
    seasons, 
    activeSeasonId,
    onSetActiveSeason, 
    attendance, 
    onSetAttendanceForDate 
}) => {
  const [currentDate, setCurrentDate] = useState(getTodayDateString());
  const [selectedTeamId, setSelectedTeamId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const activeSeason = seasons.find(s => s.id === activeSeasonId);
  const teams = activeSeason?.teams || [];
  const selectedTeam = teams.find(t => t.id === selectedTeamId) || null;
  
  // Reset selected team if active season changes or teams load
  useEffect(() => {
    if (activeSeason && activeSeason.teams.length > 0) {
        // If the current selected team is not in the new active season, reset it
        if (!activeSeason.teams.some(t => t.id === selectedTeamId)) {
            setSelectedTeamId(activeSeason.teams[0].id);
        }
    } else {
        setSelectedTeamId(null);
    }
  }, [activeSeasonId, seasons, selectedTeamId, activeSeason]);


  const handleSetAttendance = (personId: string, status: AttendanceStatus) => {
    onSetAttendanceForDate(currentDate, personId, status);
  };
  
  const attendanceForDate = attendance[currentDate] || {};

  return (
    <div className="space-y-6">
      {seasons.length > 1 && (
        <SeasonSelector
          seasons={seasons}
          currentSeasonId={activeSeasonId}
          onSelectSeason={onSetActiveSeason}
        />
      )}
      <TeamSelector
        teams={teams}
        selectedTeamId={selectedTeamId}
        onSelectTeam={setSelectedTeamId}
      />
      <div className="bg-white p-4 rounded-lg shadow-md">
        <div className="flex flex-col sm:flex-row gap-4 justify-between items-center mb-4">
            <div className="flex items-center gap-2">
                <label htmlFor="date-picker" className="font-semibold text-gray-700">Data:</label>
                <input
                    type="date"
                    id="date-picker"
                    value={currentDate}
                    onChange={(e) => setCurrentDate(e.target.value)}
                    className="p-2 border border-gray-300 rounded-md"
                />
            </div>
            <input 
                type="text"
                placeholder="Cercar per nom..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="p-2 border border-gray-300 rounded-md w-full sm:w-auto"
            />
        </div>
      </div>
      <AttendanceTracker
        team={selectedTeam}
        currentDate={currentDate}
        attendance={attendanceForDate}
        onSetAttendance={handleSetAttendance}
        searchTerm={searchTerm}
      />
    </div>
  );
};

export default AttendancePage;
