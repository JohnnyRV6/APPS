import React from 'react';
import { Person, AttendanceStatus, PersonRole, Team } from '../types';

interface AttendanceTrackerProps {
  team: Team | null;
  currentDate: string;
  attendance: Record<string, AttendanceStatus>;
  onSetAttendance: (personId: string, status: AttendanceStatus) => void;
  searchTerm: string;
}

const statusConfig = {
  [AttendanceStatus.Present]: {
    label: 'P',
    bgColor: 'bg-green-500',
    hoverBgColor: 'hover:bg-green-600',
    ringColor: 'ring-green-500',
    fullLabel: 'Present',
  },
  [AttendanceStatus.Absent]: {
    label: 'A',
    bgColor: 'bg-red-500',
    hoverBgColor: 'hover:bg-red-600',
    ringColor: 'ring-red-500',
    fullLabel: 'Absent',
  },
  [AttendanceStatus.Justified]: {
    label: 'J',
    bgColor: 'bg-yellow-500',
    hoverBgColor: 'hover:bg-yellow-600',
    ringColor: 'ring-yellow-500',
    fullLabel: 'Justificat',
  },
};

const AttendanceButton: React.FC<{
    status: AttendanceStatus,
    personId: string,
    currentStatus: AttendanceStatus | undefined,
    onClick: (personId: string, status: AttendanceStatus) => void,
}> = ({status, personId, currentStatus, onClick}) => {
    const config = statusConfig[status];
    const isSelected = currentStatus === status;

    return (
        <button
            onClick={() => onClick(personId, status)}
            title={config.fullLabel}
            className={`w-10 h-10 md:w-28 md:h-10 text-white rounded-md font-bold transition-all duration-200 flex items-center justify-center
            ${isSelected ? `${config.bgColor} shadow-lg ring-2 ring-offset-2 ${config.ringColor}` : `bg-gray-300 ${config.hoverBgColor}`}
            `}
        >
            <span className="hidden md:inline">{config.fullLabel}</span>
            <span className="md:hidden">{config.label}</span>
        </button>
    );
}

const AttendanceTracker: React.FC<AttendanceTrackerProps> = ({ team, currentDate, attendance, onSetAttendance, searchTerm }) => {
  if (!team) {
    return (
        <div className="bg-white p-6 rounded-lg shadow-md text-center">
             <p className="text-gray-500">Si us plau, selecciona un equip per veure la llista d'assistència.</p>
        </div>
    );
  }

  const filteredMembers = team.people.filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()));
  const coaches = filteredMembers.filter((p) => p.role === PersonRole.Coach);
  const players = filteredMembers.filter((p) => p.role === PersonRole.Player);
  
  const renderPersonRow = (person: Person) => (
    <div key={person.id} className="grid grid-cols-2 md:grid-cols-4 items-center gap-4 py-3 border-b border-gray-200 last:border-b-0">
      <div className="md:col-span-2">
        <p className="font-medium text-gray-800">{person.name}</p>
        <p className="text-sm text-gray-500">{person.role}</p>
      </div>
      <div className="col-span-1 md:col-span-2 flex justify-end gap-2">
        {Object.values(AttendanceStatus).map((status) => (
          <AttendanceButton
            key={status}
            status={status}
            personId={person.id}
            currentStatus={attendance[person.id]}
            onClick={onSetAttendance}
          />
        ))}
      </div>
    </div>
  );

  return (
    <div className="bg-white p-4 sm:p-6 rounded-lg shadow-md">
      <div className="flex justify-between items-baseline mb-4">
        <h2 className="text-xl font-bold text-gray-800">Llista d'assistència de {team.name}</h2>
        <span className="text-md font-semibold text-blue-600">{currentDate}</span>
      </div>
      
      {coaches.length > 0 && (
        <div className="mb-6">
          <h3 className="text-lg font-semibold text-gray-700 mb-2 border-b-2 border-blue-200 pb-1">Entrenadors</h3>
          {coaches.map(renderPersonRow)}
        </div>
      )}

      {players.length > 0 && (
         <div>
          <h3 className="text-lg font-semibold text-gray-700 mb-2 border-b-2 border-blue-200 pb-1">Jugadors</h3>
          {players.map(renderPersonRow)}
        </div>
      )}

      {filteredMembers.length === 0 && (
          <p className="text-center text-gray-500 py-8">
            {searchTerm ? `No s'ha trobat cap membre amb el nom "${searchTerm}".` : "No hi ha membres en aquest equip."}
          </p>
      )}

    </div>
  );
};

export default AttendanceTracker;
