import React from 'react';
import type { Team } from '../types';

interface TeamSelectorProps {
  teams: Team[];
  selectedTeamId: string | null;
  onSelectTeam: (teamId: string) => void;
}

const TeamSelector: React.FC<TeamSelectorProps> = ({ teams, selectedTeamId, onSelectTeam }) => {
  if (teams.length === 0) {
      return (
         <div className="bg-white p-4 rounded-lg shadow-md mb-6">
            <h2 className="text-lg font-semibold text-gray-700 mb-3">Selecciona un equip:</h2>
            <p className="text-center text-gray-500 py-4">No hi ha equips en aquesta temporada. Ves a Configuració per afegir-ne.</p>
        </div>
      )
  }
  
  return (
    <div className="bg-white p-4 rounded-lg shadow-md mb-6">
      <h2 className="text-lg font-semibold text-gray-700 mb-3">Selecciona un equip:</h2>
      <div className="flex flex-wrap gap-2">
        {teams.map((team: Team) => (
          <button
            key={team.id}
            onClick={() => onSelectTeam(team.id)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors duration-200 ${
              selectedTeamId === team.id
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            {team.name}
          </button>
        ))}
      </div>
    </div>
  );
};

export default TeamSelector;
