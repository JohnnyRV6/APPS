import React from 'react';
import { Season } from '../types';

interface SeasonSelectorProps {
  seasons: Season[];
  currentSeasonId: string | null;
  onSelectSeason: (seasonId: string) => void;
}

const SeasonSelector: React.FC<SeasonSelectorProps> = ({ seasons, currentSeasonId, onSelectSeason }) => {
  if (seasons.length === 0) {
    return (
      <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 rounded-lg shadow-md mb-6">
        <p className="font-bold">No hi ha temporades</p>
        <p>No s'han trobat temporades. Ves a Configuració per afegir-ne una.</p>
      </div>
    );
  }

  return (
    <div className="bg-white p-4 rounded-lg shadow-md mb-6">
      <label htmlFor="season-selector" className="block text-lg font-semibold text-gray-700 mb-2">
        Selecciona una temporada:
      </label>
      <select
        id="season-selector"
        value={currentSeasonId ?? ''}
        onChange={(e) => onSelectSeason(e.target.value)}
        className="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 bg-white"
      >
        {seasons.map((season) => (
          <option key={season.id} value={season.id}>
            {season.name}
          </option>
        ))}
      </select>
    </div>
  );
};

export default SeasonSelector;